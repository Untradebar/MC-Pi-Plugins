Heji! Thanks for downloading my produkt "PORTAL!".

#----------#

 DISCLAIMER

#----------#

You are not allowed to sell this product or mark it as yours.
You are not allowed to change or remove the copyright notice at the footer of this website.

Du darfst diese Produkt nicht verkaufen oder als eins von dir erstelltes Produkt bezeichnen.
Du darfst den Copyright-Hinweis im Footer der Website nicht ändern oder entfernen.

#------------#

 INSTALLATION

#------------#


1. Extract files from PORTAL.zip and copy ALL files in your folder of your webspace
2. Edit config.php and change the messages

Easy! The website is ready to go.

Any questions left?
- Twitter: @einpume

---------------

Installation:

1. Entpacke die .zip-Datei PORTAL.zip und kopiere alle entpackten Dateien in einen Ordner deines Webspaces
2. Ändere die config.php und passe die Nachrichten an deinen Server an

Easy! Die Website ist nun fertig eingerichtet und einsatzbereit.

Noch Fragen?
- Twitter: @einpume



